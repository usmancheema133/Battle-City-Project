# tanks/dummy_tank.py — Placeholder enemy tank for Phase 1
# Moves randomly and shoots occasionally.
# Phase 3 replaces this with real BFS / Greedy / A* tanks.

import random
from constants import *
from tank_base import TankBase

class DummyTank(TankBase):
    def __init__(self):
        super().__init__(
            x         = 0,
            y         = 0,
            color     = BASIC_TANK_COLOR,
            hp        = BASIC_HP,
            speed     = SPEED_SLOW,
            fire_rate = 60,       # Shoot every 2 seconds
            is_enemy  = True
        )
        self.wander_timer = 0     # How long to keep moving in current direction
        self.cur_dir      = DOWN  # Start facing downward

    def update(self, grid, all_tanks, player, bullets):
        """
        Simple random movement so Phase 1 has something moving on screen.
        Every 20 ticks, pick a new random direction.
        """
        self.tick_move_timer()
        self.tick_fire_timer()

        # Change direction occasionally
        self.wander_timer -= 1
        if self.wander_timer <= 0:
            self.cur_dir      = random.choice(DIRECTIONS)
            self.wander_timer = random.randint(15, 40)

        # Try to move in current direction
        if self.can_move():
            dx, dy = self.cur_dir
            moved = self.try_move(dx, dy, grid, all_tanks)
            if moved:
                self.reset_move_timer()
            else:
                # Blocked — pick a new direction next tick
                self.wander_timer = 0

        # Shoot randomly
        if self.can_shoot():
            bullet = self.shoot()
            if bullet:
                bullets.append(bullet)

# bullet.py — Bullet system
# A bullet travels across tiles until it hits a wall, tank, or the Eagle.

from constants import *

class Bullet:
    def __init__(self, x, y, direction, owner):
        """
        x, y      — starting tile position
        direction — (dx, dy) tuple, e.g. UP = (0,-1)
        owner     — the tank that fired this bullet (so it doesn't hit itself)
        """
        self.x         = x
        self.y         = y
        self.direction = direction
        self.owner     = owner
        self.alive     = True          # Set to False when bullet should be removed
        self.move_timer = 0            # Counts ticks before next move

    def update(self, grid, tanks, player):
        """
        Move the bullet forward by 1 tile.
        Check for collisions with walls, tanks, and the Eagle.
        Returns a string describing what was hit (for game logic).
        """
        if not self.alive:
            return None

        self.move_timer += 1
        if self.move_timer < BULLET_SPEED:
            return None   # Not time to move yet
        self.move_timer = 0

        # Move one tile in the bullet's direction
        dx, dy = self.direction
        self.x += dx
        self.y += dy

        # --- Out of bounds check ---
        if not (0 <= self.x < GRID_SIZE and 0 <= self.y < GRID_SIZE):
            self.alive = False
            return "wall"

        terrain = grid.get(self.x, self.y)

        # --- Hit Eagle → immediate game over ---
        if terrain == EAGLE:
            self.alive = False
            return "eagle"

        # --- Hit Brick → destroy it, bullet dies ---
        if terrain == BRICK:
            grid.destroy_brick(self.x, self.y)
            self.alive = False
            return "brick"

        # --- Hit Steel → bullet dies, wall stays ---
        if terrain == STEEL:
            self.alive = False
            return "steel"

        # --- Water blocks bullets too ---
        if terrain == WATER:
            self.alive = False
            return "water"

        # --- Forest: bullets PASS THROUGH (do not block) ---
        # (no action needed — bullet continues)

        # --- Hit the player tank ---
        if player and player.alive and (self.x, self.y) == (player.x, player.y):
            if self.owner != player:   # Don't let player shoot themselves
                player.take_hit()
                self.alive = False
                return "player"

        # --- Hit an enemy tank ---
        for tank in tanks:
            if tank.alive and tank != self.owner and (self.x, self.y) == (tank.x, tank.y):
                tank.take_hit()
                self.alive = False
                return "enemy"

        return None   # Bullet keeps flying

    def draw(self, screen, camera_x=0, camera_y=0):
        """Draw the bullet as a small white square on screen."""
        import pygame
        if not self.alive:
            return
        px = self.x * TILE_SIZE + TILE_SIZE // 2 - 3
        py = self.y * TILE_SIZE + TILE_SIZE // 2 - 3
        pygame.draw.rect(screen, WHITE, (px, py, 6, 6))

# grid.py — The 26x26 game world
# The grid stores terrain type for every tile.
# All tanks, bullets, and game objects live on this grid.

from constants import *

class Grid:
    def __init__(self):
        # Create a 26x26 grid, all tiles start as EMPTY (0)
        self.tiles = [[EMPTY for _ in range(GRID_SIZE)] for _ in range(GRID_SIZE)]

    def get(self, x, y):
        """Return the terrain value at tile (x, y). Returns STEEL if out of bounds."""
        if 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE:
            return self.tiles[y][x]
        return STEEL  # Treat out-of-bounds as a wall

    def set(self, x, y, value):
        """Set the terrain value at tile (x, y)."""
        if 0 <= x < GRID_SIZE and 0 <= y < GRID_SIZE:
            self.tiles[y][x] = value

    def is_passable(self, x, y):
        """Return True if a tank can move onto this tile."""
        terrain = self.get(x, y)
        return terrain in (EMPTY, FOREST)  # Only empty and forest are walkable

    def is_destructible(self, x, y):
        """Return True if a bullet can destroy this tile."""
        return self.get(x, y) == BRICK

    def destroy_brick(self, x, y):
        """Destroy a brick wall — tile becomes EMPTY permanently."""
        if self.get(x, y) == BRICK:
            self.set(x, y, EMPTY)
            return True
        return False

    def load_from_list(self, tile_list):
        """Load a map from a flat list of 676 values (26x26). Used by CSP in Phase 2."""
        for y in range(GRID_SIZE):
            for x in range(GRID_SIZE):
                self.tiles[y][x] = tile_list[y * GRID_SIZE + x]

    def place_eagle(self):
        """Place the Eagle tile at its fixed position (12, 24)."""
        ex, ey = EAGLE_POS
        self.set(ex, ey, EAGLE)

    def surround_eagle_with_brick(self):
        """Surround the Eagle with a ring of brick walls (CSP Constraint 1 - Base Safety)."""
        ex, ey = EAGLE_POS
        for dx in [-1, 0, 1]:
            for dy in [-1, 0, 1]:
                nx, ny = ex + dx, ey + dy
                if (nx, ny) != EAGLE_POS and 0 <= nx < GRID_SIZE and 0 <= ny < GRID_SIZE:
                    if self.get(nx, ny) == EMPTY:
                        self.set(nx, ny, BRICK)

    def make_simple_map(self):
        """
        A simple hardcoded test map for Phase 1.
        Phase 2 replaces this with the full CSP generator.
        """
        # Fill borders with steel
        for x in range(GRID_SIZE):
            self.set(x, 0,           STEEL)
            self.set(x, GRID_SIZE-1, STEEL)
        for y in range(GRID_SIZE):
            self.set(0,           y, STEEL)
            self.set(GRID_SIZE-1, y, STEEL)

        # Brick walls scattered around
        brick_positions = [
            (5,5),(6,5),(7,5),(8,5),
            (5,10),(6,10),(7,10),
            (10,8),(10,9),(10,10),
            (15,5),(15,6),(15,7),
            (18,12),(19,12),(20,12),
            (12,15),(12,16),
            (8,18),(9,18),(10,18),
        ]
        for bx, by in brick_positions:
            self.set(bx, by, BRICK)

        # A few steel walls (indestructible)
        for sx, sy in [(13,10),(13,11),(14,10)]:
            self.set(sx, sy, STEEL)

        # Water and forest tiles
        self.set(20, 8,  WATER)
        self.set(20, 9,  WATER)
        self.set(3,  15, FOREST)
        self.set(3,  16, FOREST)
        self.set(22, 15, FOREST)

        # Eagle at bottom-center, surrounded by brick
        self.place_eagle()
        self.surround_eagle_with_brick()

# tank_base.py — Base Tank class
# All tank types (player, basic, fast, armor, boss) inherit from this.
# Contains shared logic: movement, shooting, HP, drawing.

import pygame
from constants import *
from bullet import Bullet

class TankBase:
    def __init__(self, x, y, color, hp, speed, fire_rate, is_enemy=True):
        """
        x, y      — starting tile position on the grid
        color     — RGB tuple for drawing this tank
        hp        — how many hits before destroyed
        speed     — ticks between moves (lower = faster)
        fire_rate — ticks between shots
        is_enemy  — True for all AI tanks, False for player
        """
        self.x          = x
        self.y          = y
        self.color      = color
        self.max_hp     = hp
        self.hp         = hp
        self.speed      = speed
        self.fire_rate  = fire_rate
        self.is_enemy   = is_enemy

        self.direction  = DOWN if is_enemy else UP   # Enemies face down, player faces up
        self.alive      = True
        self.bullet     = None        # Only 1 bullet on screen at a time per tank

        self.move_timer = 0           # Counts ticks until next move
        self.fire_timer = 0           # Counts ticks until can shoot again
        self.flash_timer = 0          # Used by Armor Tank to flash when hit

    # ------------------------------------------------------------------ #
    #  MOVEMENT                                                            #
    # ------------------------------------------------------------------ #

    def try_move(self, dx, dy, grid, all_tanks):
        """
        Attempt to move one tile in direction (dx, dy).
        Returns True if move succeeded, False if blocked.
        """
        nx, ny = self.x + dx, self.y + dy

        # Check terrain — only EMPTY and FOREST are passable
        if not grid.is_passable(nx, ny):
            return False

        # Check collision with other tanks
        for tank in all_tanks:
            if tank is not self and tank.alive and tank.x == nx and tank.y == ny:
                return False

        # Move is valid
        self.x = nx
        self.y = ny
        self.direction = (dx, dy)
        return True

    def can_move(self):
        """Return True when the move timer says it's time to move."""
        return self.move_timer <= 0

    def tick_move_timer(self):
        """Count down the move timer each game tick."""
        if self.move_timer > 0:
            self.move_timer -= 1

    def reset_move_timer(self):
        """Reset move timer after a successful move."""
        self.move_timer = self.speed

    # ------------------------------------------------------------------ #
    #  SHOOTING                                                            #
    # ------------------------------------------------------------------ #

    def can_shoot(self):
        """Return True if enough ticks have passed since last shot."""
        return self.fire_timer <= 0 and (self.bullet is None or not self.bullet.alive)

    def tick_fire_timer(self):
        """Count down the fire timer each game tick."""
        if self.fire_timer > 0:
            self.fire_timer -= 1

    def shoot(self):
        """
        Fire a bullet from the front of the tank in the current facing direction.
        Only one bullet per tank at a time.
        """
        if not self.can_shoot():
            return None

        dx, dy     = self.direction
        bx, by     = self.x + dx, self.y + dy   # Bullet starts 1 tile ahead
        self.bullet = Bullet(bx, by, self.direction, owner=self)
        self.fire_timer = self.fire_rate
        return self.bullet

    # ------------------------------------------------------------------ #
    #  DAMAGE & DEATH                                                      #
    # ------------------------------------------------------------------ #

    def take_hit(self):
        """Reduce HP by 1. Mark dead if HP reaches 0."""
        self.hp -= 1
        self.flash_timer = 6   # Flash for 6 ticks when hit (visible feedback)
        if self.hp <= 0:
            self.alive = False

    # ------------------------------------------------------------------ #
    #  DRAWING                                                             #
    # ------------------------------------------------------------------ #

    def draw(self, screen):
        """Draw the tank as a colored square with a direction indicator."""
        if not self.alive:
            return

        # Flash effect when hit — alternate between color and white
        if self.flash_timer > 0:
            self.flash_timer -= 1
            draw_color = WHITE if self.flash_timer % 2 == 0 else self.color
        else:
            draw_color = self.color

        # Draw tank body
        px = self.x * TILE_SIZE + 2
        py = self.y * TILE_SIZE + 2
        size = TILE_SIZE - 4
        pygame.draw.rect(screen, draw_color, (px, py, size, size))

        # Draw a small direction indicator (darker square in the facing direction)
        cx = self.x * TILE_SIZE + TILE_SIZE // 2
        cy = self.y * TILE_SIZE + TILE_SIZE // 2
        dx, dy = self.direction
        # Barrel tip
        bx = cx + dx * (TILE_SIZE // 2 - 2)
        by = cy + dy * (TILE_SIZE // 2 - 2)
        pygame.draw.rect(screen, BLACK, (bx - 3, by - 3, 6, 6))

        # HP bar for tanks with more than 1 HP
        if self.max_hp > 1:
            bar_w = TILE_SIZE - 4
            bar_h = 3
            filled = int(bar_w * self.hp / self.max_hp)
            pygame.draw.rect(screen, RED,   (px, py - 5, bar_w, bar_h))
            pygame.draw.rect(screen, GREEN, (px, py - 5, filled, bar_h))

# main.py — Battle City | Entry point
# Run this file to start the game: python main.py
#
# Phase 1 contents:
#   - 26x26 grid with terrain rendering
#   - Player tank (WASD / arrow keys to move, SPACE to shoot)
#   - Bullet system (destroys bricks, kills tanks, game over on Eagle hit)
#   - Dummy enemy tanks (random movement — real AI comes in Phase 3)
#   - HUD (lives, enemies remaining, level)
#   - Win / Lose conditions

import pygame
import sys

from constants  import *
from grid       import Grid
from player     import PlayerTank
from renderer   import Renderer
from spawner    import Spawner
from tanks.dummy_tank import DummyTank

# ------------------------------------------------------------------ #
#  HELPER — build the dummy enemy pool for Phase 1                   #
# ------------------------------------------------------------------ #
def make_dummy_pool(count=20):
    """Create a pool of dummy tanks. Phase 3 replaces these with real AI tanks."""
    return [DummyTank() for _ in range(count)]

# ------------------------------------------------------------------ #
#  HELPER — collect all active bullets from player + enemies          #
# ------------------------------------------------------------------ #
def gather_bullets(player, enemy_tanks):
    bullets = []
    if player.bullet and player.bullet.alive:
        bullets.append(player.bullet)
    for tank in enemy_tanks:
        if tank.bullet and tank.bullet.alive:
            bullets.append(tank.bullet)
    return bullets

# ------------------------------------------------------------------ #
#  MAIN GAME FUNCTION                                                 #
# ------------------------------------------------------------------ #
def run_game():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Battle City — AL2002 AI Project")
    clock  = pygame.font.SysFont(None, 22)
    font   = pygame.font.SysFont(None, 22)
    clock2 = pygame.time.Clock()

    renderer = Renderer(screen, font)

    # ---- Set up Level 1 (Phase 1: simple hardcoded map) ----
    level_num  = 1
    game_state = STATE_PLAYING
    msg_timer  = 0   # How many ticks to show a WIN/LOSE message

    grid   = Grid()
    grid.make_simple_map()   # Phase 2 will call the CSP generator instead

    player  = PlayerTank()
    pool    = make_dummy_pool(20)
    spawner = Spawner(pool)

    # Tracks all enemy tanks currently on the map
    enemy_tanks = []

    # Separate bullet list for collision detection
    all_bullets = []

    # ------------------------------------------------------------------ #
    #  MAIN GAME LOOP                                                     #
    # ------------------------------------------------------------------ #
    while True:

        # ---- EVENT HANDLING ----
        for event in pygame.event.get():
            if event.type == pygame.QUIT:
                pygame.quit()
                sys.exit()
            if event.type == pygame.KEYDOWN:
                # Press R to restart after win/lose
                if event.key == pygame.K_r and game_state != STATE_PLAYING:
                    run_game()   # Restart
                    return

        # ---- STEP 1 — INPUT (player) ----
        keys = pygame.key.get_pressed()

        if game_state == STATE_PLAYING:

            # ---- STEP 2 — AGENT DECISIONS + STEP 3 MOVE (enemies) ----
            for tank in enemy_tanks:
                if tank.alive:
                    tank.update(grid, enemy_tanks + [player], player, all_bullets)

            # ---- PLAYER INPUT + MOVE ----
            player_bullet = player.handle_input(keys, grid, enemy_tanks)
            if player_bullet:
                all_bullets.append(player_bullet)

            # ---- STEP 4 & 5 — BULLET UPDATE ----
            # Rebuild bullet list (removes dead bullets from previous tick)
            all_bullets = [b for b in all_bullets if b.alive]
            # Also add any newly fired enemy bullets this tick
            for tank in enemy_tanks:
                if tank.bullet and tank.bullet.alive and tank.bullet not in all_bullets:
                    all_bullets.append(tank.bullet)

            eagle_hit = False
            for bullet in list(all_bullets):
                result = bullet.update(grid, enemy_tanks, player)
                if result == "eagle":
                    eagle_hit = True

            # ---- STEP 6 & 7 — COLLISION & STATE UPDATE ----
            if eagle_hit:
                game_state = STATE_LOSE
                msg_timer  = 120

            # Handle player death
            if not player.alive:
                respawned = player.respawn()
                if not respawned:
                    game_state = STATE_LOSE
                    msg_timer  = 120

            # Remove dead enemies from active list
            enemy_tanks = [t for t in enemy_tanks if t.alive]

            # ---- STEP 8 — SPAWN ----
            new_tank = spawner.update(player, grid)
            if new_tank:
                enemy_tanks.append(new_tank)

            # ---- STEP 10 — WIN/LOSE CHECK ----
            if spawner.all_done() and game_state == STATE_PLAYING:
                game_state = STATE_WIN
                msg_timer  = 150

        else:
            # Countdown message timer
            if msg_timer > 0:
                msg_timer -= 1

        # ---- STEP 9 — RENDER ----
        screen.fill(BLACK)
        renderer.draw_grid(grid)
        renderer.draw_bullets(all_bullets)
        renderer.draw_tanks(player, enemy_tanks)
        renderer.draw_hud(player, spawner.total_remaining(), level_num)

        if game_state == STATE_WIN:
            renderer.draw_message("YOU WIN!  Press R", GREEN)
        elif game_state == STATE_LOSE:
            renderer.draw_message("GAME OVER  Press R", RED)

        pygame.display.flip()
        clock2.tick(FPS)

# ------------------------------------------------------------------ #
#  ENTRY POINT                                                        #
# ------------------------------------------------------------------ #
if __name__ == "__main__":
    run_game()

# player.py — The human-controlled player tank
# Reads keyboard input and moves/shoots accordingly.

import pygame
from constants import *
from tank_base import TankBase

class PlayerTank(TankBase):
    def __init__(self):
        super().__init__(
            x         = PLAYER_START[0],
            y         = PLAYER_START[1],
            color     = PLAYER_COLOR,
            hp        = PLAYER_HP,
            speed     = SPEED_SLOW,    # Player moves same speed as Basic Tank
            fire_rate = 20,            # Can shoot every 20 ticks (~0.67 seconds at 30fps)
            is_enemy  = False
        )
        self.lives = PLAYER_LIVES      # Player starts with 3 lives

    def handle_input(self, keys, grid, all_tanks):
        """
        Read keyboard input and move or shoot.
        Called once per game tick.
        """
        self.tick_move_timer()
        self.tick_fire_timer()

        moved = False

        # Movement — arrow keys or WASD
        if self.can_move():
            if keys[pygame.K_UP]    or keys[pygame.K_w]:
                moved = self.try_move(0, -1, grid, all_tanks)
                if not moved: self.direction = UP
            elif keys[pygame.K_DOWN]  or keys[pygame.K_s]:
                moved = self.try_move(0,  1, grid, all_tanks)
                if not moved: self.direction = DOWN
            elif keys[pygame.K_LEFT]  or keys[pygame.K_a]:
                moved = self.try_move(-1, 0, grid, all_tanks)
                if not moved: self.direction = LEFT
            elif keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                moved = self.try_move( 1, 0, grid, all_tanks)
                if not moved: self.direction = RIGHT

            if moved:
                self.reset_move_timer()

        # Shoot — SPACE or Z key
        if keys[pygame.K_SPACE] or keys[pygame.K_z]:
            return self.shoot()   # Returns bullet or None

        return None

    def respawn(self):
        """Respawn the player after losing a life."""
        self.lives -= 1
        if self.lives <= 0:
            self.alive = False   # No lives left — game over
            return False
        # Reset position and HP
        self.x     = PLAYER_START[0]
        self.y     = PLAYER_START[1]
        self.hp    = PLAYER_HP
        self.alive = True
        self.direction = UP
        self.bullet    = None
        return True

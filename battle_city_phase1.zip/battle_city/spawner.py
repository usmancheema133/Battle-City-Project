# spawner.py — Controls when and where enemies spawn
# At most 3 active enemies on screen at once.
# Spawns from the 3 top spawn points in rotation.

from constants import *

class Spawner:
    def __init__(self, enemy_pool):
        """
        enemy_pool — list of tank instances waiting to enter the map.
        They are spawned one at a time as active tanks die.
        """
        self.pool          = list(enemy_pool)  # Copy of all tanks for this level
        self.active        = []                # Currently alive tanks on map
        self.spawn_index   = 0                 # Rotates through the 3 spawn points
        self.spawn_timer   = 0                 # Ticks to wait before next spawn
        self.spawn_delay   = 60                # 60 ticks = 2 seconds between spawns
        self.max_active    = 3                 # Never more than 3 enemies at once

    def update(self, player, grid):
        """
        Each tick: check if we should spawn the next tank.
        Returns a newly spawned tank if one was spawned, else None.
        """
        # Remove dead tanks from active list
        self.active = [t for t in self.active if t.alive]

        # Nothing to spawn
        if not self.pool:
            return None

        # Wait until below max active
        if len(self.active) >= self.max_active:
            return None

        # Count down spawn timer
        self.spawn_timer -= 1
        if self.spawn_timer > 0:
            return None

        # Time to spawn — pick spawn point in rotation
        spawn_point = SPAWN_POINTS[self.spawn_index % len(SPAWN_POINTS)]
        self.spawn_index += 1

        # Fairness check: don't spawn within 10 Manhattan tiles of player
        if player and player.alive:
            px, py = player.x, player.y
            sx, sy = spawn_point
            if abs(sx - px) + abs(sy - py) < 10:
                # Skip this cycle — try again next tick
                self.spawn_timer = 20
                return None

        # Pop next tank from pool and place it at spawn point
        tank = self.pool.pop(0)
        tank.x     = spawn_point[0]
        tank.y     = spawn_point[1]
        tank.alive = True

        self.active.append(tank)
        self.spawn_timer = self.spawn_delay
        return tank

    def all_done(self):
        """Return True when pool is empty AND all active tanks are dead."""
        return len(self.pool) == 0 and len(self.active) == 0

    def total_remaining(self):
        """Return how many enemies are still left (pool + active)."""
        return len(self.pool) + len(self.active)

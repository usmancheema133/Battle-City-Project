# constants.py — All game-wide values in one place
# Change values here and they update everywhere in the game

# --- Screen & Grid ---
TILE_SIZE = 24           # Each tile is 24x24 pixels on screen
GRID_SIZE = 26           # The game world is 26x26 tiles
SCREEN_WIDTH  = TILE_SIZE * GRID_SIZE + 200   # Extra 200px for HUD on the right
SCREEN_HEIGHT = TILE_SIZE * GRID_SIZE         # Height = exactly the grid

FPS = 30                 # Frames per second — game speed

# --- Terrain Tile Values ---
EMPTY  = 0   # Open road — tanks can move freely
BRICK  = 1   # Destructible wall — bullets destroy it
STEEL  = 2   # Indestructible wall — bullets bounce off / die
WATER  = 3   # Water — tanks blocked, bullets pass through
FOREST = 4   # Forest — tanks can enter, but are hidden inside
EAGLE  = 5   # The base — if any bullet hits this, game over

# --- Terrain Colors (RGB) for rendering ---
TERRAIN_COLORS = {
    EMPTY:  (40,  40,  40),    # Dark grey road
    BRICK:  (180, 80,  30),    # Orange-brown brick
    STEEL:  (150, 150, 150),   # Silver steel
    WATER:  (30,  100, 200),   # Blue water
    FOREST: (30,  120, 30),    # Dark green forest
    EAGLE:  (255, 215, 0),     # Gold eagle base
}

# --- Fixed Map Positions ---
EAGLE_POS        = (12, 24)   # Eagle always at bottom-center
PLAYER_START     = (4,  24)   # Player spawns bottom-left area
SPAWN_POINTS     = [(0, 0), (12, 0), (24, 0)]  # Enemy spawn: Left, Center, Right

# --- Tank Speed (ticks between moves — lower = faster) ---
SPEED_SLOW   = 4    # Basic Tank:  moves every 4 ticks
SPEED_MEDIUM = 3    # Armor Tank:  moves every 3 ticks
SPEED_FAST   = 2    # Fast Tank:   moves every 2 ticks

# --- Bullet Speed ---
BULLET_SPEED = 2    # Bullets move 2 tiles per tick (faster than tanks)

# --- Direction Vectors (dx, dy) ---
UP    = ( 0, -1)
DOWN  = ( 0,  1)
LEFT  = (-1,  0)
RIGHT = ( 1,  0)
DIRECTIONS = [UP, DOWN, LEFT, RIGHT]

# --- Colors for UI / Tanks ---
WHITE  = (255, 255, 255)
BLACK  = (0,   0,   0)
RED    = (255, 0,   0)
GREEN  = (0,   200, 0)
YELLOW = (255, 220, 0)
GRAY   = (100, 100, 100)

# --- Tank Colors ---
PLAYER_COLOR      = (0,   200, 255)   # Cyan — player tank
BASIC_TANK_COLOR  = (200, 200, 0)     # Yellow — basic enemy
FAST_TANK_COLOR   = (255, 100, 0)     # Orange — fast enemy
ARMOR_TANK_COLOR  = (100, 100, 255)   # Blue — armor enemy
BOSS_TANK_COLOR   = (200, 0,   200)   # Purple — boss tank

# --- Tank HP ---
PLAYER_HP      = 1    # Player tank dies in 1 hit (loses a life)
BASIC_HP       = 1
FAST_HP        = 1
ARMOR_HP       = 4    # Armor tank needs 4 hits

# --- Player Lives ---
PLAYER_LIVES   = 3    # Player starts with 3 lives

# --- Game States ---
STATE_PLAYING  = "playing"
STATE_WIN      = "win"
STATE_LOSE     = "lose"
STATE_NEXT_LVL = "next_level"
